package com.fire.chat.firechat.notifications

import com.fire.chat.firechat.models.Data

class Sender(var data:Data,var to:String)