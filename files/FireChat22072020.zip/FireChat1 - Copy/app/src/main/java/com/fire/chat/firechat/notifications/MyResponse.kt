package com.fire.chat.firechat.notifications

class MyResponse {

    var success = 0
}