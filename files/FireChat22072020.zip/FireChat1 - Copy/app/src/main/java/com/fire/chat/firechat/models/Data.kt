package com.fire.chat.firechat.models

class Data(var user:String,var icon:Int,var body:String,var title:String,var sented:String) {
    constructor() : this("",0,"","","")
}